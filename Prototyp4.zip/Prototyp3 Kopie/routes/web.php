<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auftragserstellung;
use App\Http\Controllers\Ausgabe;
use App\Http\Controllers\Start;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Routes für die Eingabe:
// index() um view "eingabe.blade.php" aufzurufen
// store() um Werte über Controller Auftragserstellung an die Datenbank zu übergeben
Route::get('/eingabe', [Auftragserstellung::class, 'index']) -> name('eingabe');
Route::post('/eingabe', [Auftragserstellung::class, 'store']);

//Route index() um view "ausgabe.blade.php" aufzurufen
Route::get('/ausgabe', [Ausgabe::class, 'index']) -> name('ausgabe');

//Route index() um view "start.blade.php" aufzurufen
Route::get('/start', [Start::class, 'index']) -> name('start');

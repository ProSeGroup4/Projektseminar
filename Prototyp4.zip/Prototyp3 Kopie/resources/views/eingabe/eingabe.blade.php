{{-- Diesen View mit View "layouts.app" erweitern, um u. a. Navigationsleiste zu haben --}}
@extends("layouts.app")

{{-- Ab hier wird der Content der Eingabe geladen --}}
@section("content")
    <h1> Auftragserstellung </h1>
  
    <form action="{{route ('eingabe') }}" method="POST">
        
        {{-- ??? --}}
        @csrf
        
        <div class="form-group">
            <label for="InputOrderID">AuftragsID:</label>
            <input type="text" class="form-control" value="auto generiert" readonly>
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputClient">Auftraggeber:</label>
            <input type="text" class="form-control @error("InputClient") border border-danger @enderror" name="InputClient" placeholder="Bauhaus" value="{{ old("InputClient") }}">

            @error("InputClient") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message = "Das ist ein Pflichtfeld"}}
                </div>
            @enderror
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputItemNumber">Artikelnummer:</label>
            <select class="form-control" name="InputItemNumber" value="{{ old("InputItemNumber") }}">
                <option selected>#10111</option>
                <option>#10222</option>
                <option>#11131</option>
                <option>#11242</option>
                <option>#20111</option>
                <option>#20222</option>
                <option>#21131</option>
                <option>#21242</option>
                <option>#30111</option>
                <option>#30222</option>
                <option>#31131</option>
                <option>#31242</option>
            <p></select></p>
        </div>

        <div class="form-group">
            <label for="InputAmount">Menge:</label>
            <input type="number" class="form-control @error("InputAmount") border border-danger @enderror" min="1" max="1000" name="InputAmount" placeholder="1-1000" value="{{ old("InputAmount") }}">

            @error("InputAmount") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message = "Das ist ein Pflichtfeld"}}
                </div>
            @enderror
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputColour">Farbe:</label>
            <select class="form-control" name="InputColour" value="{{ old("InputColour") }}">
                <option selected>Standard</option>
                <option>Schwarz</option>
                <option>Gelb</option>
                <option>Blau</option>
            <p></select></p>
        </div>

        <div class="form-group">
            <label for="Coating">Beschichtungen:</label>
            <select class="form-control" name="Coating" value="{{ old("Coating") }}">
                <option selected>0</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
            <p></select></p>
        </div>

        <div class="form-group">
            <label for="InputTime">(((Deadline))):</label>
            <input type="time" class="form-control @error("InputTime") border border-danger @enderror" name="InputTime" value="{{ old("InputTime") }}">

            @error("InputTime") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message = "Das ist ein Pflichtfeld"}}
                </div>
            @enderror
            <p></p>
        </div>

        <button class="btn btn-primary" href="/start">hinzufügen</button>
        
    </form>

@endsection
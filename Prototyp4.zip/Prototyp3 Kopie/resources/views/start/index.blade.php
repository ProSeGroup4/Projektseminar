@extends("layouts.app")

@section("content")

    <div class="tab-content">
        <div id="Start" data-tab-content class="active">
        <h1> Konfiguration </h1>
        <input type="checkbox" onClick="toggle(this)">
        Alle Aufträge Auswählen

        <div class="table-responsive" style="height: 145px;">  <!--Table schauen ab wann scrollbar-->

            <?php 
                $aufträge = DB::table('aufträge')->get();
            ?>

{{-- 
        Todo:
        1) Maschinen ausgefallen auswählbar
        2) Button für Schnittstelle
        3) Tabelle sortieren/ suchen
        4) Thead scrollable
        5) foo ändern
 --}}

            <table class="table">
                <thead>
                    <tr>
                        <th></th>
                        <th>Auftragsnummer</th>
                        <th>Auftraggeber</th>
                        <th>Artikelnummer</th>
                        <th>Menge</th>
                        <th>Farbe</th>
                        <th>Uhrzeit</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($aufträge as $auftrag)
                    <tr>
                        <td><input type="checkbox" onclick="auswahl()" id={{ $auftrag->InputOrderID }} name="foo"></td> <!--Name foo änern-->
                        <td>{{ $auftrag->InputOrderID }}</td>
                        <td>{{ $auftrag->InputClient }}</td>
                        <td>{{ $auftrag->InputItemNumber }}</td>
                        <td>{{ $auftrag->InputAmount }}</td>
                        <td>{{ $auftrag->InputColour }}</td>
                        <td>{{ $auftrag->InputTime }}</td>
                    </tr>
                    @endforeach
                </tbody>
             </table> 


        </div>                    
    </div>                 

          <!--Abfragen welche inputs aus Aufträge "an" sind-->
        <div class="d-flex p-2 border border-grey border-1">                            
            <b>Ausgewählte Aufträge:</b>
            <b id="ausgewählteAufträge"></b>
        </div>
        <p></p>

            <div class="Optimieren">
            <div>
                <b>Optimieren nach:</b>
            </div>
        <div class="Auswahlliste" role="group">
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked>
            <label class="form-check-label" for="flexRadioDefault1">
            Durchlaufzeit
        </label>
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
            <label class="form-check-label" for="flexRadioDefault2">
            Termintreue
        </label>
            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault3">
            <label class="form-check-label" for="flexRadioDefault3">
            Kosten
        </label>
        </div>

        {{-- 
        Ankreuzen ob Maschine ausgefalllen ist 
        --}}


        <p></p>
        <b>Genetischen Algorithmus konfigurieren:</b>
        <br>
        
        <label for="Population">Populationsgröße:</label>
        <input required type="number" class="form-control" min="20" max="100" id="Population" placeholder="20 - 100">
        
        <label for="mutationRate">Mutationsrate:</label>
        <input required type="number" class="form-control" min="0.05" max="0.2" id="mutationRate" placeholder="0.05 - 0.2">

        <label for="cycles">Maximale Durchlaufzeit:</label>
        <p><input required type="number" class="form-control" min="1" max="5" id="cycles" placeholder="1 - 5 min."></p>


        <a href="{{ route('ausgabe') }}" class="btn btn-primary">ausführen</a>
    
    </div>
@endsection
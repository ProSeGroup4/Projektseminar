<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('maschinen', function (Blueprint $table) {
                        $table->bigIncrements('Maschinen_ID');              
                        $table->string('Name');
                        $table->string('Durchlaufzeit_pro_Stueck');
                        $table->string('Umruestzeit');
                        $table->string('is_available');
                        $table->string('aktuellerAufsatz');
                        $table->string('Startzeit');
                        $table->string('Endzeit');
                    });   
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('datashare');
    }
};

<?php $__env->startSection("content"); ?>

    <form action="/start" method="post">
        <?php echo csrf_field(); ?>
    <!-- "cross-site request forgery" generiert einen geheimen Token innerhalb der HTTP-Request,
    um Hacker zu hindern, den Web Service zu manipulieren.-->    

    <div class="tab-content">
        <div id="Start" data-tab-content class="active">
        <h1> Konfiguration </h1>
        <input type="checkbox" onClick="toggle(this)">
        Alle Aufträge Auswählen

        <div class="table-responsive" style="height: 145px;">  <!--Table schauen ab wann scrollbar-->

            <?php 
                $users = DB::table('aufträge')->get();
            ?>

            <table>
                <tr>
                    <th></th>
                    <th>Auftragsnummer</th>
                    <th>Auftragsgeber</th>
                    <th>Artikelnummer</th>
                    <th>Menge</th>
                    <th>Farbe</th>
                    <th>Uhrzeit</th>
                </tr>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox" onclick="auswahl()" id=<?php echo e($user->InputOrderID); ?> value=<?php echo e($user->InputOrderID); ?> name="foo"></td> <!--Name foo ändern-->
                    <td><?php echo e($user->InputOrderID); ?></td>
                    <td><?php echo e($user->InputClient); ?></td>
                    <td><?php echo e($user->InputItemNumber); ?></td>
                    <td><?php echo e($user->InputAmount); ?></td>
                    <td><?php echo e($user->InputColour); ?></td>
                    <td><?php echo e($user->InputTime); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </table> 


        </div>                    
    </div>                 

          <!--Abfragen welche inputs aus Aufträge "an" sind-->
        <div class="d-flex p-2 border border-grey border-1">                            
            <b>Ausgewählte Aufträge:</b>
            <b id="ausgewählteAufträge"></b>
        </div>
        <p></p>

        <div class="form-group">
            <label for="InputMachine"><b>Auswählen bei Maschinendefekt:</b></label>
            <select class="form-control selectpicker" name="InputMachine" multiple data-live-search="true">
                <option>M1.1</option>
                <option>M1.2</option>
                <option>M1.3</option>
                <option>M2.1</option>
                <option>M2.2</option>
                <option>M3.1</option>
                <option>M3.2</option>
                <option>M4.1</option>
                <option>M4.2</option>
                <option>M5.1</option>
                <option>M5.2</option>
                <option>M6.1</option>
                <option>M6.2</option>
                <option>M7.1</option>
                <option>M7.2</option>
                <option>M7.3</option>
            <p></select></p>

            <div class="Optimieren">
            <div>
                <b>Optimieren nach:</b>
            </div>
        <div class="Auswahlliste" role="group">
            <input class="form-check-input" type="radio" name="flexRadioDefault" value="1" checked>
            <label class="form-check-label" for="flexRadioDefault2">
            Termintreue
        </label>
        <input class="form-check-input" type="radio" name="flexRadioDefault" value="2">
            <label class="form-check-label" for="flexRadioDefault1">
            Durchlaufzeit
        </label>
            <input class="form-check-input" type="radio" name="flexRadioDefault" value="3">
            <label class="form-check-label" for="flexRadioDefault3">
            Kosten
        </label>
        </div>


        <p></p>
        <b>Genetischen Algorithmus konfigurieren:</b>
        <br>
        
        <label for="Population">Populationsgröße:</label>
        <input required type="number" class="form-control <?php $__errorArgs = ["Population"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="20" max="100" id="Population" placeholder="20 - 100" name="Population">
        
        <?php $__errorArgs = ["Population"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <!-- Felder umbenennen -->
                <div class="text-danger">
                    <?php echo e($message="Populationsgröße muss innerhalb von 20 - 100 sein!"); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p></p>

        <label for="mutationRate">Mutationsrate:</label>
        <input required type="number" class="form-control <?php $__errorArgs = ["mutationRate"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="0.05" max="0.2" id="mutationRate" placeholder="0.05 - 0.2" name="mutationRate">

        <?php $__errorArgs = ["mutationRate"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <!-- Felder umbenennen -->
                <div class="text-danger">
                    <?php echo e($message="Die Mutationsrate muss zwischen 0,05 - 0,2 sein!"); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p></p>

        <label for="cycles">Maximale Durchlaufzeit:</label>
        <p><input required type="number" class="form-control <?php $__errorArgs = ["cycles"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" min="1" max="5" id="cycles" placeholder="1 - 5 min." name="cycles"></p> <!--Added the names for referencing in Start.php -->

        <?php $__errorArgs = ["cycles"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <!-- Felder umbenennen -->
                <div class="text-danger">
                    <?php echo e($message="Die max. Durchlaufzeit muss zwischen 1 und 5 Min. sein!"); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <p></p>

        <a href="<?php echo e(route('ausgabe')); ?>" class="btn btn-primary">Diagrammerstellung</a>   
    
        <input type="submit" value="Genetischer Algo. START" onclick="dataShare();"> <!-- Button für die Datenschnittstelle zwischen
                                                                                    Front- und Backend: Eingabedaten werden in den Gen. Algo. eingespeist!-->
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Oliver\Documents\Studium\SoSe22\ProSe EMA\Genetischer Algo\Genetischer Algorithmus\Prototyp3\resources\views/start/index.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Datashare;
use App\Models\Maschinen;

class Start extends Controller
{
    public function index() {
        return view("start.index");
        $dataShare = Datashare::all();              /* Diese Zeile erstellt die Variable dataShare und inherits alle verfügb. Methoden von der DataShare Table*/
    }


     public function store() {

        $dataShare = new Datashare();

        $dataShare->optimieren = request('flexRadioDefault');
        $dataShare->populationsgroeße = request('Population');  /*Darf nicht ungerade sein, in Zehner Schritte vorgeben - default Wert auf 100*/
        $dataShare->mutationsrate = request('mutationRate');    /*Muss herausgenommen werden */
        $dataShare->maxdurchlaufzeit = request('cycles');
 /*     error_log(request('flexRadioDefault'));     1 = Termintreue; 2 = Durchlaufzeit; 3 = Kosten (Radio buttons von links nach rechts)
        error_log(request('Population'));           Testen, ob Population gespeichert wird.
        error_log(request('mutationRate'));         Testen, ob mutationRate gespeichert wird.
        error_log(request('cycles'));               Testen, ob max. Durchlaufzeit gespeichert wird.*/
        
/*      error_log($dataShare);                      error_log zum Testen ob Array erstellt wird*/
        $dataShare->save();

        return redirect('/start');              /*Auf dem Uniserver muss hier wahrscheinlich '/public' anstelle von '/start' */
    } 

    public function defect() {

        $machineDefect = new Maschinen();

        $machineDefect->is_availabe = request('InputMachine');
        
      error_log($machineDefect);                   /*   error_log zum Testen ob Werte gespeichert werden*/
        $machineDefect->save();
    } 
}
?>



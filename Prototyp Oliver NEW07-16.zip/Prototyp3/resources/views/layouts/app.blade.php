<!DOCTYPE html>
<html lang="en">
<head>
    <title>Genetischer Algorithmus</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

<!-- Neueste Bootstrap-Version: -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" 
    crossorigin="anonymous">
    <!--Folgender Link und das script in Zeile 14 & 15 sind für den Selectpicker multiple dropdown fuer Maschinenauswahl im Falle eines Defekts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <link rel="stylesheet" href="css/tabs.css">
</head>
<body>
    <ul class="tabs">
        <li class="tab">
            <a href="/start" class="active tab">Konfiguration</a>
        </li>
        <li class="tab">
            <a href="{{ route('eingabe') }}" class="tab">Auftragserstellung</a>
        </li>
        <li class="tab">
            <a href="{{ route('ausgabe') }}" class="tab">Produktionsplan</a>
        </li>
    </ul>

    <script src="js/safeAuftrag.js"></script>
    <script src="js/zurück.js"></script>
    <script src="js/storage.js"></script>
    <script src="js/addRow.js"></script>
    <script src="js/tabs.js"></script>
    <script src="js/tablesort.js"></script>
    <script src="js/selectAll.js"></script>
    <script src="js/showAuftrag.js"></script>

    {{-- Zeig hier den Content an --}}
    @yield("content")

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
    <!--Beide scripte hier sind für den Selectpicker multiple dropdown bei der Maschinenauswahl im Falle eines oder mehreren Defekts -->
</body>
</html>
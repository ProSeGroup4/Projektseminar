function auswahl() {
    var Text="";
    / jede Checkbox überprüfen und wenn ausgewaehlt dann auflisten : /
    checkboxes = document.getElementsByName('foo');
    for(var i=0, n=checkboxes.length;i<n;i++) {
        if(checkboxes[i].checked) {
            Text=Text+checkboxes[i].id+", "+"\n";
        }
    }
    / Text im Ausgabefeld setzen : */
    document.getElementById("ausgewählteAufträge").innerHTML = Text;
}

function dataShare() {
    var aktiveAufträge = Array();                       /* Diese Variable speichert die ausgewählten Aufträge, kann im Backend eingespeist werden!*/
    / jede Checkbox überprüfen und wenn ausgewaehlt dann speichern : /
    checkboxes = document.getElementsByName('foo');
    for(var i=0, n=checkboxes.length;i<n;i++) {
        if(checkboxes[i].checked) {
            aktiveAufträge.push(checkboxes[i].id);      /*Alle Aufträge sind standardmäßig ausgewählt! Deshalb kann Backend die Auftrags-DB ziehen,
                                                        im Sonderfall "nicht alle Aufträge sind ausgewählt" kann Backend die Variable "aktiveAufträge" (links) nutzen.*/
        }
    }
/*        document.write(aktiveAufträge);              Diese Zeile testet, ob alle ausgewählten Aufträge mit aktiveAufträge gespeichert werden*/


/*     var radioButton = document.getElementsByName('flexRadioDefault');        <- nicht funktionaler code!
        document.write(" " , radioButton[0]);
    var popSize = document.getElementsByName('Population').value;
        document.write(popSize); */
/*     var mutRate = document.getElementById('mutationRate');
    document.write(mutRate); */
}


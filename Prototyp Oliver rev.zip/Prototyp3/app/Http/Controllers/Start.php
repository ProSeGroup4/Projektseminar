<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Datashare;

class Start extends Controller
{
    public function index() {
        return view("start.index");
        $dataShare = Datashare::all();              /* Diese Zeile erstellt die Variable dataShare und inherits alle verfügb. Methoden von der DataShare Table*/
    }


     public function store() {

        $dataShare = new Datashare();

        $dataShare->optimieren = request('flexRadioDefault');
        $dataShare->populationsgröße = request('Population');
        $dataShare->mutationsrate = request('mutationRate');
        $dataShare->maxdurchlaufzeit = request('cycles');
        $dataShare->maschinendefekt = request('InputMachine');
 /*     error_log(request('flexRadioDefault'));     flexRadioDefault1 = Durchlaufzeit;  flexRadioDefault2 = Termintreue; flexRadioDefault3 = Kosten (von links nach rechts)
        error_log(request('Population'));           Testen, ob Population gespeichert wird.
        error_log(request('mutationRate'));         Testen, ob mutationRate gespeichert wird.
        error_log(request('cycles'));               Testen, ob max. Durchlaufzeit gespeichert wird.*/
        
/*      error_log($dataShare);                      error_log zum Testen ob Array erstellt wird*/
        $dataShare->save();

        return redirect('/start');
    } 
}
?>



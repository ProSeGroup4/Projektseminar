@extends("layouts.app")

@section("content")
    <h1> Auftragserstellung </h1>

{{-- 

    Todo:
    1) Auftragsnummer Fortlaufend
    2) Artikelnummer auswählbar
    3) Beschichtung hinzufügen
    4) Deadline richtiges Wort? 

    --}}
  
    <form action="{{route ('eingabe') }}" method="POST">
        @csrf
        
        <div class="form-group">
            <label for="InputOrderID">AuftragsID (fortlaufend):</label>
            <input type="text" class="form-control @error("InputOrderID") border border-danger @enderror" name ="InputOrderID" placeholder="auto generiert" size="5" value="{{ old("InputOrderID") }}" readonly>
            <!-- Oliver: placeholder umbenannt und readonly gesetzt, da nun automatisch fortlaufend generiert wird und AuftragsID als primary function gesetzt wurde!-->

            @error("InputOrderID") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message}}
                </div>
            @enderror
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputClient">Auftraggeber:</label>
            <input type="text" class="form-control @error("InputOrderID") border border-danger @enderror" name="InputClient" placeholder="Bauhaus" value="{{ old("InputClient") }}">

            @error("InputClient") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message}}
                </div>
            @enderror
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputItemNumber">Artikelnummer:</label>
            <input type="text" class="form-control @error("InputOrderID") border border-danger @enderror" pattern="#[0-9]{5}" name="InputItemNumber" placeholder="#00001" size="6" value="{{ old("InputItemNumber") }}">

            @error("InputItemNumber") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message}}
                </div>
            @enderror
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputAmount">Menge:</label>
            <input type="number" class="form-control @error("InputOrderID") border border-danger @enderror" min="1" max="1000" name="InputAmount" placeholder="1-1000" value="{{ old("InputAmount") }}">

            @error("InputAmount") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message}}
                </div>
            @enderror
            <p></p>
        </div>

        <div class="form-group">
            <label for="InputColour">Farbe:</label>
            <select class="form-control" name="InputColour" value="{{ old("InputColour") }}">
                <option selected>Standard</option>
                <option>Schwarz</option>
                <option>Gelb</option>
                <option>Blau</option>
            <p></select></p>

        <div class="form-group">
            <label for="InputTime">(((Deadline))):</label>
            <input type="time" class="form-control @error("InputOrderID") border border-danger @enderror" name="InputTime" value="{{ old("InputTime") }}">

            @error("InputTime") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message}}
                </div>
            @enderror
            <p></p>
        </div>

        <button class="btn btn-primary" href="/start">hinzufügen</button>
        
    </form>

@endsection
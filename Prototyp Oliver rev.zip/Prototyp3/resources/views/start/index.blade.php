@extends("layouts.app")

@section("content")

    <form action="/start" method="post">
        @csrf

    <div class="tab-content">
        <div id="Start" data-tab-content class="active">
        <h1> Konfiguration </h1>
        <input type="checkbox" onClick="toggle(this)">
        Alle Aufträge Auswählen

        <div class="table-responsive" style="height: 145px;">  <!--Table schauen ab wann scrollbar-->

            <?php 
                $users = DB::table('aufträge')->get();
            ?>

            <table>
                <tr>
                    <th></th>
                    <th>Auftragsnummer</th>
                    <th>Auftragsgeber</th>
                    <th>Artikelnummer</th>
                    <th>Menge</th>
                    <th>Farbe</th>
                    <th>Uhrzeit</th>
                </tr>
                @foreach ($users as $user)
                <tr>
                    <td><input type="checkbox" onclick="auswahl()" id={{ $user->InputOrderID }} value={{ $user->InputOrderID }} name="foo"></td> <!--Name foo ändern-->
                    <td>{{ $user->InputOrderID }}</td>
                    <td>{{ $user->InputClient }}</td>
                    <td>{{ $user->InputItemNumber }}</td>
                    <td>{{ $user->InputAmount }}</td>
                    <td>{{ $user->InputColour }}</td>
                    <td>{{ $user->InputTime }}</td>
                </tr>
                @endforeach
             </table> 


        </div>                    
    </div>                 

          <!--Abfragen welche inputs aus Aufträge "an" sind-->
        <div class="d-flex p-2 border border-grey border-1">                            
            <b>Ausgewählte Aufträge:</b>
            <b id="ausgewählteAufträge"></b>
        </div>
        <p></p>

        <div class="form-group">
            <label for="InputMachine"><b>Auswählen bei Maschinendefekt:</b></label>
            <select class="form-control" name="InputMachine" value="{{ old("InputMachine") }}">
                <option selected>Select</option>                    <!-- Select ist Standardplatzhalter bei voller Funktionstüchtigkeit aller Maschinen.-->
                <option>Walze1.1</option>
                <option>Walze1.2</option>
                <option>Walze1.3</option>
                <option>Drehmaschine2.1</option>
                <option>Drehmaschine2.2</option>
                <option>Presse3.1</option>
                <option>Presse3.2</option>
                <option>Presse3.3</option>
                <option>Presse3.4</option>
                <option>Schweißmaschine4.1</option>
                <option>Schweißmaschine4.2</option>
                <option>Beschichtmaschine5.1</option>
                <option>Beschichtmaschine5.2</option>
                <option>Beschichtmaschine5.3</option>
                <option>Lackiermaschine6.1</option>
                <option>Lackiermaschine6.2</option>
            <p></select></p>

            <div class="Optimieren">
            <div>
                <b>Optimieren nach:</b>
            </div>
        <div class="Auswahlliste" role="group">
            <input class="form-check-input" type="radio" name="flexRadioDefault" value="flexRadioDefault1" checked>
            <label class="form-check-label" for="flexRadioDefault1">
            Durchlaufzeit
        </label>
            <input class="form-check-input" type="radio" name="flexRadioDefault" value="flexRadioDefault2">
            <label class="form-check-label" for="flexRadioDefault2">
            Termintreue
        </label>
            <input class="form-check-input" type="radio" name="flexRadioDefault" value="flexRadioDefault3">
            <label class="form-check-label" for="flexRadioDefault3">
            Kosten
        </label>
        </div>


        <p></p>
        <b>Genetischen Algorithmus konfigurieren:</b>
        <br>
        
        <label for="Population">Populationsgröße:</label>
        <input required type="number" class="form-control @error("Population") border border-danger @enderror" min="20" max="100" id="Population" placeholder="20 - 100" name="Population">
        
        @error("Population") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message="Populationsgröße muss innerhalb von 20 - 100 sein!"}}
                </div>
            @enderror
            <p></p>

        <label for="mutationRate">Mutationsrate:</label>
        <input required type="number" class="form-control @error("mutationRate") border border-danger @enderror" min="0.05" max="0.2" id="mutationRate" placeholder="0.05 - 0.2" name="mutationRate">

        @error("mutationRate") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message="Die Mutationsrate muss zwischen 0,05 - 0,2 sein!"}}
                </div>
            @enderror
            <p></p>

        <label for="cycles">Maximale Durchlaufzeit:</label>
        <p><input required type="number" class="form-control @error("cycles") border border-danger @enderror" min="1" max="5" id="cycles" placeholder="1 - 5 min." name="cycles"></p> <!--Added the names for referencing in Start.php -->

        @error("cycles") <!-- Felder umbenennen -->
                <div class="text-danger">
                    {{$message="Die max. Durchlaufzeit muss zwischen 1 und 5 Min. sein!"}}
                </div>
            @enderror
            <p></p>

        <a href="{{ route('ausgabe') }}" class="btn btn-primary">Diagrammerstellung</a>   
    
        <input type="submit" value="Genetischer Algo. START" onclick="dataShare();"> <!-- Button für die Datenschnittstelle zwischen
                                                                                    Front- und Backend: Eingabedaten werden in den Gen. Algo. eingespeist!-->
        </form>
    </div>
@endsection
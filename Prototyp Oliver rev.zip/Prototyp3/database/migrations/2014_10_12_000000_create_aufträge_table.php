<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('aufträge', function (Blueprint $table) {
            $table->bigIncrements('InputOrderID');              /* Von string zu bigIncrements geändert für automatische fortlaufende Nummerierung und primary function */
            $table->string('InputClient');
            $table->string('InputItemNumber');
            $table->string('InputAmount');
            $table->string('InputColour');
            $table->string('InputTime');
            $table->string('updated_at');
            $table->string('created_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('aufträge');
    }
};

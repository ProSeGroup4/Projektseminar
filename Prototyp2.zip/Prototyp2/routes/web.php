<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auftragserstellung;
use App\Http\Controllers\Ausgabe;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/eingabe', [Auftragserstellung::class, 'index']) -> name('eingabe');
Route::post('/eingabe', [Auftragserstellung::class, 'store']);

Route::get('/ausgabe', [Ausgabe::class, 'index']) -> name('ausgabe');

Route::get('/start', function () {
    return view('start.index');
});

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Auftragserstellung extends Controller
{
    public function index() {
        return view("eingabe.eingabe");
    }

    public function store(Request $request) {
         //Validieren
        $this -> validate($request, [
            "InputOrderID" => array("required","regex:/#[0-9]{4}/"), // "/ ... /" als "begrenzer"
            "InputClient" => "required",
            "InputItemNumber" => array("required","regex:/#[0-9]{5}/"),
            "InputAmount" => "required|min:1|max:1000",
            "InputTime" => "required"
        ]);

        //Auftrag speichern

        //redirect
    }
}
